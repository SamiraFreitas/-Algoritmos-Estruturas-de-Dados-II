#ifndef MANIPULACAO_ARQUIVOS_H
#define MANIPULACAO_ARQUIVOS_H

#include <stdio.h>

/*descobrindo o número de registros em um arquivo*/
int tamanho_arquivo(FILE *arq);

#endif
